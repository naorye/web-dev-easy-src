define(function() {
	return {
		googleApiKey: 'AIzaSyDEMpzAwWS40E6TBjIA_XH76QfO0YSsvDc'
	};
});